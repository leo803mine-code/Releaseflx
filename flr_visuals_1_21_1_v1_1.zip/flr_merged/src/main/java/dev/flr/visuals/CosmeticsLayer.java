package dev.flr.visuals;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.util.Mth;
import org.joml.Matrix4f;

/** Procedural cosmetic layer (halo / wings / cape). No textures, no per-frame allocations. */
public final class CosmeticsLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final int N = 24;
    private static final float[] COS = new float[N + 1], SIN = new float[N + 1];
    static {
        for (int i = 0; i <= N; i++) {
            COS[i] = (float) Math.cos(i * Math.PI * 2 / N);
            SIN[i] = (float) Math.sin(i * Math.PI * 2 / N);
        }
    }

    public CosmeticsLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) { super(parent); }

    @Override
    public void render(PoseStack pose, MultiBufferSource buffers, int light, AbstractClientPlayer p,
                       float limbSwing, float limbSwingAmount, float partialTick,
                       float ageInTicks, float netHeadYaw, float headPitch) {
        Minecraft mc = Minecraft.getInstance();
        if (!Config.master || p.isInvisible() || mc.player == null) return;
        if (mc.player != p) {
            if (!Config.others) return;
            if (p.distanceToSqr(mc.player) > Config.maxDistance * Config.maxDistance) return;
        }

        VertexConsumer out = buffers.getBuffer(RenderType.debugQuads());
        Matrix4f m = pose.last().pose();
        int c = Config.color();
        float phase = (p.tickCount + partialTick) * 0.08f * Config.speed;

        if (Config.cape) cape(out, m, phase, c);
        if (Config.wings) wings(out, m, phase, c, p.onGround(), p.isCrouching());
        if (Config.halo) halo(out, m, phase, c);
    }

    private static void halo(VertexConsumer v, Matrix4f m, float phase, int c) {
        float s = Config.scale;
        float y = -0.64f - 0.02f * s + Mth.sin(phase * .75f) * .02f;
        int soft = al(c, 100);
        for (int i = 0; i < N; i++) {
            float k = .5f + .5f * Mth.sin(phase * 2f + i * .5f);
            int bright = al(c, (int) (140 + 115 * k));
            quad(v, m, soft, soft,
                    COS[i] * .20f * s, y, SIN[i] * .20f * s, COS[i] * .34f * s, y, SIN[i] * .34f * s,
                    COS[i + 1] * .34f * s, y, SIN[i + 1] * .34f * s, COS[i + 1] * .20f * s, y, SIN[i + 1] * .20f * s);
            quad(v, m, bright, bright,
                    COS[i] * .225f * s, y + .004f, SIN[i] * .225f * s, COS[i] * .30f * s, y + .004f, SIN[i] * .30f * s,
                    COS[i + 1] * .30f * s, y + .004f, SIN[i + 1] * .30f * s, COS[i + 1] * .225f * s, y + .004f, SIN[i + 1] * .225f * s);
        }
    }

    private static void wings(VertexConsumer v, Matrix4f m, float phase, int c, boolean grounded, boolean sneak) {
        float size = Config.wingSize * Config.scale;
        float flap = Mth.sin(phase * (grounded ? 1.8f : 3.8f)) * (grounded ? .12f : .32f);
        float fold = sneak ? .5f : 1f;
        int root = al(c, 220), tip = al(c, 70);
        for (int side = -1; side <= 1; side += 2) {
            for (int i = 0; i < 6; i++) {
                float ang = -.9f + i * .30f + flap * fold;
                float len = (.66f - i * .05f) * size;
                float rx = side * .08f, ry = .04f + i * .03f, rz = .15f;
                float tx = rx + side * Mth.cos(ang) * len * fold;
                float ty = ry + Mth.sin(ang) * len;
                float tz = rz + .10f + i * .015f;
                quad(v, m, root, tip,
                        rx, ry, rz, rx, ry + .075f, rz,
                        tx, ty + .05f, tz, tx, ty, tz);
            }
        }
    }

    private static void cape(VertexConsumer v, Matrix4f m, float phase, int c) {
        float sway = Mth.sin(phase * 1.2f);
        final int n = 6;
        for (int i = 0; i < n; i++) {
            float k0 = i / (float) n, k1 = (i + 1) / (float) n;
            float y0 = k0 * 1.14f, y1 = k1 * 1.14f;
            float z0 = .14f + sway * .09f * k0 * k0 + .05f * k0, z1 = .14f + sway * .09f * k1 * k1 + .05f * k1;
            float w0 = .24f + .05f * k0, w1 = .24f + .05f * k1;
            quad(v, m, al(c, (int) (150 - 110 * k0)), al(c, (int) (150 - 110 * k1)),
                    -w0, y0, z0, w0, y0, z0, w1, y1, z1, -w1, y1, z1);
        }
    }

    /** FIX: corners are now in loop order (old quads were bow-ties and the cape had zero height). */
    private static void quad(VertexConsumer v, Matrix4f m, int cA, int cB,
                             float x0, float y0, float z0, float x1, float y1, float z1,
                             float x2, float y2, float z2, float x3, float y3, float z3) {
        vertex(v, m, x0, y0, z0, cA); vertex(v, m, x1, y1, z1, cA);
        vertex(v, m, x2, y2, z2, cB); vertex(v, m, x3, y3, z3, cB);
    }

    private static void vertex(VertexConsumer v, Matrix4f m, float x, float y, float z, int color) {
        v.addVertex(m, x, y, z).setColor(color).setUv(0, 0).setLight(0xF000F0).setNormal(0, 1, 0);
    }

    private static int al(int rgb, int alpha) {
        return (rgb & 0xFFFFFF) | (Math.max(0, Math.min(255, (int) (alpha * Config.opacity))) << 24);
    }
}
