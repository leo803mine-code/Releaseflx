package dev.flr.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import org.joml.Vector3f;

public final class GameEvents {
    private static final ParticleOptions[] FIXED = {
            ParticleTypes.END_ROD, ParticleTypes.SOUL_FIRE_FLAME, ParticleTypes.FLAME,
            ParticleTypes.ELECTRIC_SPARK, ParticleTypes.CHERRY_LEAVES, ParticleTypes.GLOW};

    private static int tick, budget, dustColor = -1;
    private static float phase;
    private static Vec3 lastPos;
    private static ParticleOptions dust;

    private GameEvents() {}

    public static void tick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;

        while (FlrKeys.MASTER.consumeClick()) {
            Config.master = !Config.master;
            p.displayClientMessage(Component.literal("FLR Visuals: " + (Config.master ? "ON" : "OFF")), true);
            Config.save();
        }
        while (FlrKeys.MENU.consumeClick()) mc.setScreen(new CosmeticsScreen());

        tick++;
        phase += 0.08f * Config.speed;
        budget = Config.effectiveBudget();
        Vec3 pos = p.position();
        if (!Config.master || !Config.particles || budget <= 0 || mc.isPaused() || p.isSpectator() || p.isInvisible()) {
            lastPos = pos;
            return;
        }

        float sc = Config.scale;
        if (Config.halo && tick % 2 == 0) {
            for (int i = 0; i < 8 && budget > 0; i++) {
                double a = phase + i * Math.PI * 2.0 / 8.0;
                spawn(mc, p.getX() + Math.cos(a) * 0.42 * sc, p.getY() + p.getBbHeight() + 0.62,
                        p.getZ() + Math.sin(a) * 0.42 * sc, 0, 0.006, 0);
            }
        }
        if (Config.aura && tick % 3 == 0 && budget > 0) {
            double a = phase * 0.8;
            spawn(mc, p.getX() + Math.cos(a) * 0.48 * sc, p.getY() + 0.9 + Math.sin(phase) * 0.35,
                    p.getZ() + Math.sin(a) * 0.48 * sc, 0, 0.004, 0);
        }
        if (Config.trail && lastPos != null && pos.distanceToSqr(lastPos) > 0.01 && budget > 0) {
            Vec3 q = lastPos.lerp(pos, 0.45);
            spawn(mc, q.x, q.y + 0.65, q.z, 0, 0.008, 0);
        }
        if (Config.hitSparks && p.swinging && p.attackAnim > 0.1f && tick % 4 == 0) {
            for (int i = 0; i < 3 && budget > 0; i++) {
                double a = phase * 2 + i * Math.PI * 2 / 3;
                spawn(mc, p.getX() + Math.cos(a) * 0.65, p.getY() + 1.0, p.getZ() + Math.sin(a) * 0.65,
                        Math.cos(a) * .015, .015, Math.sin(a) * .015);
            }
        }
        lastPos = pos;
    }

    private static ParticleOptions particle() {
        int t = Config.particleType;
        if (t <= 0) {
            int c = Config.color();
            if (dust == null || c != dustColor) {
                dustColor = c;
                dust = new DustParticleOptions(new Vector3f(((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f), 0.8f);
            }
            return dust;
        }
        return FIXED[Math.min(t - 1, FIXED.length - 1)];
    }

    private static void spawn(Minecraft mc, double x, double y, double z, double vx, double vy, double vz) {
        if (budget <= 0) return;
        budget--;
        mc.level.addParticle(particle(), x, y, z, vx, vy, vz);
    }
}
