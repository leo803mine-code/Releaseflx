package dev.flr.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleFunction;
import java.util.function.DoubleSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/** Tabbed FLR panel: toggles, sliders, theme swatches, presets and a live player preview. */
public final class CosmeticsScreen extends Screen {
    private static final ResourceLocation LOGO =
            ResourceLocation.fromNamespaceAndPath(FlrVisuals.MOD_ID, "textures/gui/logo.png");
    private static final int PW = 388, PH = 236, SB = 78, CW = 196, HEAD = 28, FOOT = 20;
    private static final String[] TABS = {"Cosmetics", "Effects", "Style", "System"};
    private static int tab;

    private final List<List<Row>> pages = new ArrayList<>();
    private int scroll;
    private Row dragging;

    public CosmeticsScreen() { super(Component.literal("FLR VISUALS")); }

    @Override public boolean isPauseScreen() { return false; }

    // ---------------------------------------------------------------- rows

    private static final class Row {
        static final int TOGGLE = 0, SLIDER = 1, CHOICE = 2, BUTTON = 3, SWATCH = 4;
        final int kind;
        final String label;
        BooleanSupplier bget; Consumer<Boolean> bset;
        double min, max; DoubleSupplier dget; DoubleConsumer dset; DoubleFunction<String> fmt;
        String[] opts; IntSupplier iget; IntConsumer iset;
        Runnable run;

        Row(int kind, String label) { this.kind = kind; this.label = label; }

        int h() {
            return switch (kind) {
                case SLIDER -> 26;
                case BUTTON -> 22;
                case SWATCH -> 38;
                default -> 20;
            };
        }

        void draw(GuiGraphics g, Font f, int x, int y, int w, int mx, int my, int accent) {
            boolean hover = mx >= x - 2 && mx < x + w + 2 && my >= y && my < y + h();
            if (hover && kind != BUTTON) g.fill(x - 2, y, x + w + 2, y + h(), 0x14FFFFFF);
            switch (kind) {
                case TOGGLE -> {
                    g.drawString(f, label, x + 2, y + 6, 0xFFD6D6E2, false);
                    pill(g, x + w - 28, y + 4, bget.getAsBoolean(), accent);
                }
                case SLIDER -> {
                    String val = fmt.apply(dget.getAsDouble());
                    g.drawString(f, label, x + 2, y + 3, 0xFFD6D6E2, false);
                    g.drawString(f, val, x + w - f.width(val) - 2, y + 3, accent, false);
                    double fr = Math.max(0, Math.min(1, (dget.getAsDouble() - min) / (max - min)));
                    int tx0 = x + 2, tx1 = x + w - 2, kx = tx0 + (int) ((tx1 - tx0) * fr);
                    g.fill(tx0, y + 16, tx1, y + 20, 0xFF2B2B38);
                    g.fill(tx0, y + 16, kx, y + 20, accent);
                    g.fill(kx - 2, y + 13, kx + 2, y + 23, 0xFFFFFFFF);
                }
                case CHOICE -> {
                    String t = "< " + opts[iget.getAsInt()] + " >";
                    g.drawString(f, label, x + 2, y + 6, 0xFFD6D6E2, false);
                    g.drawString(f, t, x + w - f.width(t) - 2, y + 6, accent, false);
                }
                case BUTTON -> {
                    g.fill(x + 2, y + 2, x + w - 2, y + 20, hover ? 0xFF2E2E42 : 0xFF20202C);
                    g.fill(x + 2, y + 2, x + 4, y + 20, accent);
                    g.drawCenteredString(f, label, x + w / 2, y + 7, 0xFFFFFFFF);
                }
                case SWATCH -> {
                    g.drawString(f, label, x + 2, y + 3, 0xFFD6D6E2, false);
                    for (int i = 0; i < Config.THEME_NAMES.length; i++) {
                        int sx = x + 2 + i * 19, sy = y + 16;
                        if (Config.theme == i) g.fill(sx - 2, sy - 2, sx + 16, sy + 16, 0xFFFFFFFF);
                        if (i == Config.THEME_RAINBOW) {
                            for (int k = 0; k < 7; k++) g.fill(sx + k * 2, sy, sx + k * 2 + 2, sy + 14, 0xFF000000 | Config.hsv(k / 7f, .65f, 1f));
                        } else {
                            int col = i == Config.THEME_CUSTOM ? Config.hsv(Config.hue, .7f, 1f) : Config.THEME_COLORS[i];
                            g.fill(sx, sy, sx + 14, sy + 14, 0xFF000000 | col);
                        }
                    }
                }
                default -> {}
            }
        }

        boolean click(int x, int y, int w, double mx, double my, int btn) {
            switch (kind) {
                case TOGGLE -> bset.accept(!bget.getAsBoolean());
                case SLIDER -> drag(x, w, mx);
                case CHOICE -> {
                    int n = opts.length;
                    iset.accept(Math.floorMod(iget.getAsInt() + (btn == 1 ? -1 : 1), n));
                }
                case BUTTON -> run.run();
                case SWATCH -> {
                    int i = (int) ((mx - (x + 2)) / 19);
                    if (my >= y + 14 && my <= y + 32 && i >= 0 && i < Config.THEME_NAMES.length) Config.theme = i;
                }
                default -> { return false; }
            }
            return true;
        }

        void drag(int x, int w, double mx) {
            if (kind != SLIDER) return;
            double fr = Math.max(0, Math.min(1, (mx - (x + 2)) / (w - 4)));
            dset.accept(min + fr * (max - min));
        }
    }

    private static void pill(GuiGraphics g, int x, int y, boolean on, int accent) {
        g.fill(x, y, x + 26, y + 12, on ? accent : 0xFF2B2B38);
        int kx = on ? x + 15 : x + 1;
        g.fill(kx, y + 1, kx + 10, y + 11, 0xFFFFFFFF);
    }

    private static Row toggle(String l, BooleanSupplier g, Consumer<Boolean> s) {
        Row r = new Row(Row.TOGGLE, l); r.bget = g; r.bset = s; return r;
    }
    private static Row slider(String l, double min, double max, DoubleSupplier g, DoubleConsumer s, DoubleFunction<String> f) {
        Row r = new Row(Row.SLIDER, l); r.min = min; r.max = max; r.dget = g; r.dset = s; r.fmt = f; return r;
    }
    private static Row choice(String l, String[] o, IntSupplier g, IntConsumer s) {
        Row r = new Row(Row.CHOICE, l); r.opts = o; r.iget = g; r.iset = s; return r;
    }
    private static Row button(String l, Runnable run) { Row r = new Row(Row.BUTTON, l); r.run = run; return r; }

    // ---------------------------------------------------------------- layout

    @Override
    protected void init() {
        pages.clear();
        pages.add(List.of(
                toggle("Halo", () -> Config.halo, v -> Config.halo = v),
                toggle("Wings", () -> Config.wings, v -> Config.wings = v),
                toggle("Cape", () -> Config.cape, v -> Config.cape = v),
                toggle("Show on other players", () -> Config.others, v -> Config.others = v),
                slider("Wing size", .5, 2, () -> Config.wingSize, v -> Config.wingSize = (float) v, v -> String.format("%.1fx", v)),
                slider("Effect scale", .5, 2, () -> Config.scale, v -> Config.scale = (float) v, v -> String.format("%.1fx", v))));
        pages.add(List.of(
                toggle("Particles", () -> Config.particles, v -> Config.particles = v),
                toggle("Aura", () -> Config.aura, v -> Config.aura = v),
                toggle("Trail", () -> Config.trail, v -> Config.trail = v),
                toggle("Hit sparks", () -> Config.hitSparks, v -> Config.hitSparks = v),
                choice("Particle style", Config.PARTICLE_NAMES, () -> Config.particleType, v -> Config.particleType = v),
                slider("Particle budget", 0, 40, () -> Config.particleBudget, v -> Config.particleBudget = (int) Math.round(v), v -> String.valueOf((int) Math.round(v))),
                toggle("Auto performance", () -> Config.autoPerf, v -> Config.autoPerf = v)));
        Row swatches = new Row(Row.SWATCH, "Theme");
        pages.add(List.of(
                swatches,
                slider("Custom hue", 0, 1, () -> Config.hue, v -> { Config.hue = (float) v; Config.theme = Config.THEME_CUSTOM; }, v -> (int) (v * 360) + "\u00B0"),
                slider("Opacity", .2, 1, () -> Config.opacity, v -> Config.opacity = (float) v, v -> (int) Math.round(v * 100) + "%"),
                slider("Animation speed", .25, 3, () -> Config.speed, v -> Config.speed = (float) v, v -> String.format("%.2fx", v)),
                toggle("Fog tint", () -> Config.fogTint, v -> Config.fogTint = v)));
        pages.add(List.of(
                slider("Max distance", 8, 96, () -> Config.maxDistance, v -> Config.maxDistance = Math.round(v), v -> (int) Math.round(v) + " m"),
                toggle("HUD badge", () -> Config.hud, v -> Config.hud = v),
                button("Preset: Minimal", () -> Config.preset(0)),
                button("Preset: Balanced", () -> Config.preset(1)),
                button("Preset: Max", () -> Config.preset(2)),
                button("Reset to defaults", Config::reset)));
    }

    private int px() { return (width - PW) / 2; }
    private int py() { return (height - PH) / 2; }
    private int cx() { return px() + SB + 10; }
    private int cy() { return py() + HEAD + 6; }
    private int ch() { return PH - HEAD - FOOT - 8; }

    private int totalHeight() {
        int t = 0;
        for (Row r : pages.get(tab)) t += r.h();
        return t;
    }

    private void clampScroll() { scroll = Math.max(0, Math.min(scroll, Math.max(0, totalHeight() - ch()))); }

    // ---------------------------------------------------------------- render

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        int x0 = px(), y0 = py();
        int accent = Config.color() | 0xFF000000;
        int soft = (accent & 0xFFFFFF) | 0x66000000;

        g.fill(0, 0, width, height, 0x99000000);
        g.fill(x0 - 1, y0 - 1, x0 + PW + 1, y0 + PH + 1, accent);
        g.fill(x0, y0, x0 + PW, y0 + PH, 0xFF0E0E15);

        // header
        g.fill(x0, y0, x0 + PW, y0 + HEAD, 0xFF16161F);
        g.fill(x0, y0 + HEAD, x0 + PW, y0 + HEAD + 1, soft);
        g.blit(LOGO, x0 + 8, y0 + 5, 18, 18, 0f, 0f, 256, 256, 256, 256);
        g.drawString(font, "FLR VISUALS", x0 + 32, y0 + 6, accent, false);
        g.drawString(font, "cosmetics client \u00B7 v1.1", x0 + 32, y0 + 16, 0xFF7A7A90, false);
        g.drawString(font, "Master", x0 + PW - 98, y0 + 10, 0xFFD6D6E2, false);
        pill(g, x0 + PW - 64, y0 + 8, Config.master, accent);
        boolean overClose = mx >= x0 + PW - 28 && mx < x0 + PW - 10 && my >= y0 + 5 && my < y0 + 23;
        g.fill(x0 + PW - 28, y0 + 5, x0 + PW - 10, y0 + 23, overClose ? 0xFF8A2A3A : 0xFF20202C);
        g.drawCenteredString(font, "x", x0 + PW - 19, y0 + 10, 0xFFFFFFFF);

        // sidebar
        g.fill(x0, y0 + HEAD + 1, x0 + SB, y0 + PH, 0xFF12121A);
        for (int i = 0; i < TABS.length; i++) {
            int ty = y0 + HEAD + 8 + i * 24;
            boolean act = i == tab, hv = mx >= x0 + 6 && mx < x0 + SB - 4 && my >= ty && my < ty + 20;
            if (act) g.fill(x0 + 6, ty, x0 + SB - 4, ty + 20, soft & 0x40FFFFFF | 0x30000000);
            else if (hv) g.fill(x0 + 6, ty, x0 + SB - 4, ty + 20, 0x14FFFFFF);
            if (act) g.fill(x0 + 6, ty, x0 + 8, ty + 20, accent);
            g.drawString(font, TABS[i], x0 + 14, ty + 6, act ? 0xFFFFFFFF : 0xFF8C8CA0, false);
        }

        // footer
        g.fill(x0 + SB, y0 + PH - FOOT, x0 + PW, y0 + PH, 0xFF12121A);
        g.drawString(font, "O menu  \u00B7  P master  \u00B7  wheel: scroll  \u00B7  RMB: back", x0 + SB + 10, y0 + PH - 14, 0xFF6C6C80, false);

        // content
        clampScroll();
        int cx = cx(), cy = cy(), ch = ch();
        g.enableScissor(cx - 4, cy, cx + CW + 4, cy + ch);
        int y = cy - scroll;
        for (Row r : pages.get(tab)) {
            if (y + r.h() > cy && y < cy + ch) r.draw(g, font, cx, y, CW, mx, my, accent);
            y += r.h();
        }
        g.disableScissor();
        int total = totalHeight();
        if (total > ch) {
            int bh = Math.max(16, ch * ch / total);
            int by = cy + (int) ((long) (ch - bh) * scroll / (total - ch));
            g.fill(cx + CW + 4, by, cx + CW + 6, by + bh, soft);
        }

        // live preview
        int bx = x0 + PW - 98, bw = 88, byy = y0 + HEAD + 6, bhh = PH - HEAD - FOOT - 8;
        g.fill(bx - 1, byy - 1, bx + bw + 1, byy + bhh + 1, soft);
        g.fill(bx, byy, bx + bw, byy + bhh, 0xFF0A0A10);
        g.drawCenteredString(font, "PREVIEW", bx + bw / 2, byy + 4, 0xFF6C6C80);
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            InventoryScreen.renderEntityInInventoryFollowsMouse(g, bx, byy + 14, bx + bw, byy + bhh - 2, 52, 0.0625f, mx, my, mc.player);
        }
    }

    // ---------------------------------------------------------------- input

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        int x0 = px(), y0 = py();
        if (mx >= x0 + PW - 28 && mx < x0 + PW - 10 && my >= y0 + 5 && my < y0 + 23) { onClose(); return true; }
        if (mx >= x0 + PW - 100 && mx < x0 + PW - 36 && my >= y0 + 4 && my < y0 + 24) { Config.master = !Config.master; return true; }
        for (int i = 0; i < TABS.length; i++) {
            int ty = y0 + HEAD + 8 + i * 24;
            if (mx >= x0 + 6 && mx < x0 + SB - 4 && my >= ty && my < ty + 20) {
                if (tab != i) { tab = i; scroll = 0; }
                return true;
            }
        }
        int cx = cx(), cy = cy(), ch = ch();
        if (my >= cy && my < cy + ch && mx >= cx - 2 && mx < cx + CW + 2) {
            int y = cy - scroll;
            for (Row r : pages.get(tab)) {
                if (my >= y && my < y + r.h()) {
                    if (r.click(cx, y, CW, mx, my, btn)) dragging = r;
                    return true;
                }
                y += r.h();
            }
        }
        return super.mouseClicked(mx, my, btn);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (dragging != null) { dragging.drag(cx(), CW, mx); return true; }
        return super.mouseDragged(mx, my, btn, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int btn) {
        if (dragging != null) { dragging = null; Config.save(); return true; }
        return super.mouseReleased(mx, my, btn);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        scroll -= (int) (sy * 14);
        clampScroll();
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (FlrKeys.MENU.matches(key, scan)) { onClose(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void removed() {
        Config.save();
        super.removed();
    }
}
