package dev.flr.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.util.Mth;
import net.minecraft.world.level.material.FogType;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;

public final class ClientEvents {
    private static long windowStart = System.nanoTime();
    private static int frames;

    private ClientEvents() {}

    public static void registerKeys(RegisterKeyMappingsEvent e) {
        e.register(FlrKeys.MENU);
        e.register(FlrKeys.MASTER);
    }

    /** FIX: the cosmetics layer was never attached to the player renderer, so nothing was drawn. */
    public static void addLayers(EntityRenderersEvent.AddLayers e) {
        for (var model : e.getSkins()) {
            Object r = e.getSkin(model);
            if (r instanceof PlayerRenderer pr) pr.addLayer(new CosmeticsLayer(pr));
        }
    }

    /** FPS counter (for auto-performance) + optional HUD badge. */
    public static void gui(RenderGuiEvent.Post e) {
        frames++;
        long now = System.nanoTime();
        if (now - windowStart >= 1_000_000_000L) {
            Config.fps = frames;
            frames = 0;
            windowStart = now;
        }
        Minecraft mc = Minecraft.getInstance();
        if (Config.hud && mc.screen == null && !mc.options.hideGui) {
            String s = "FLR " + (Config.master ? Config.THEME_NAMES[Config.theme] : "OFF") + "  " + Config.fps + " fps";
            e.getGuiGraphics().drawString(mc.font, s, 4, 4, Config.color() | 0xFF000000, true);
        }
    }

    /** Pretty Fog: gently tints the fog towards the theme colour (not underwater / in lava). */
    public static void fog(ViewportEvent.ComputeFogColor e) {
        if (!Config.master || !Config.fogTint) return;
        if (e.getCamera().getFluidInCamera() != FogType.NONE) return;
        int c = Config.color();
        float k = 0.10f;
        e.setRed(Mth.lerp(k, e.getRed(), ((c >> 16) & 255) / 255f));
        e.setGreen(Mth.lerp(k, e.getGreen(), ((c >> 8) & 255) / 255f));
        e.setBlue(Mth.lerp(k, e.getBlue(), (c & 255) / 255f));
    }
}
