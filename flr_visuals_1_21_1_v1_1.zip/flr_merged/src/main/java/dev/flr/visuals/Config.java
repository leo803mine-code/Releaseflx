package dev.flr.visuals;

import net.neoforged.fml.loading.FMLPaths;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Runtime client settings (saved to config/flrvisuals.properties). */
public final class Config {
    public static boolean master = true, halo = true, wings = true, cape = true, others = false;
    public static boolean particles = true, aura = true, trail = true, hitSparks = true, autoPerf = true;
    public static boolean fogTint = true, hud = false;

    public static final String[] THEME_NAMES = {"Purple", "Cyan", "Pink", "Gold", "Green", "Custom", "Rainbow"};
    public static final int[] THEME_COLORS = {0x7A4FFF, 0x2EE7FF, 0xFF50A8, 0xFFD04D, 0x5BE36A};
    public static final int THEME_CUSTOM = 5, THEME_RAINBOW = 6;
    public static final String[] PARTICLE_NAMES = {"Dust (theme)", "End Rod", "Soul Flame", "Flame", "Electric", "Cherry", "Glow"};

    public static int theme = 0, particleType = 0, particleBudget = 18;
    public static float hue = 0.75f, scale = 1f, wingSize = 1f, speed = 1f, opacity = 1f;
    public static double maxDistance = 48.0;

    /** Measured by ClientEvents. */
    public static int fps = 60;

    private Config() {}

    public static int color() {
        if (theme == THEME_RAINBOW) return hsv(((System.currentTimeMillis() / 40) % 360) / 360f, .65f, 1f);
        if (theme == THEME_CUSTOM) return hsv(hue, .7f, 1f);
        return THEME_COLORS[Math.floorMod(theme, THEME_COLORS.length)];
    }

    public static int hsv(float h, float s, float v) {
        float r, g, b;
        int i = (int) (h * 6);
        float f = h * 6 - i, p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
        switch (i % 6) {
            case 0: r = v; g = t; b = p; break;
            case 1: r = q; g = v; b = p; break;
            case 2: r = p; g = v; b = t; break;
            case 3: r = p; g = q; b = v; break;
            case 4: r = t; g = p; b = v; break;
            default: r = v; g = p; b = q; break;
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    /** Particle budget lowered automatically when FPS is low. */
    public static int effectiveBudget() {
        if (!autoPerf) return particleBudget;
        if (fps < 20) return 0;
        if (fps < 35) return particleBudget / 2;
        return particleBudget;
    }

    public static void preset(int n) {
        switch (n) {
            case 0 -> { halo = true; wings = false; cape = false; aura = false; trail = false; hitSparks = false; particleBudget = 6; maxDistance = 24; }
            case 1 -> { halo = true; wings = true; cape = true; aura = true; trail = false; hitSparks = true; particleBudget = 18; maxDistance = 48; }
            default -> { halo = true; wings = true; cape = true; aura = true; trail = true; hitSparks = true; particleBudget = 36; maxDistance = 64; }
        }
        particles = true;
    }

    public static void reset() {
        master = true; others = false; fogTint = true; hud = false; autoPerf = true;
        theme = 0; particleType = 0; hue = 0.75f; scale = 1f; wingSize = 1f; speed = 1f; opacity = 1f;
        preset(1);
    }

    private static Path file() { return FMLPaths.CONFIGDIR.get().resolve("flrvisuals.properties"); }

    public static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            Properties p = new Properties();
            try (Reader r = Files.newBufferedReader(f)) { p.load(r); }
            master = b(p, "master", master); halo = b(p, "halo", halo); wings = b(p, "wings", wings);
            cape = b(p, "cape", cape); others = b(p, "others", others); particles = b(p, "particles", particles);
            aura = b(p, "aura", aura); trail = b(p, "trail", trail); hitSparks = b(p, "hitSparks", hitSparks);
            autoPerf = b(p, "autoPerf", autoPerf); fogTint = b(p, "fogTint", fogTint); hud = b(p, "hud", hud);
            theme = Math.max(0, Math.min(THEME_NAMES.length - 1, (int) n(p, "theme", theme)));
            particleType = Math.max(0, Math.min(PARTICLE_NAMES.length - 1, (int) n(p, "particleType", particleType)));
            particleBudget = (int) Math.max(0, Math.min(40, n(p, "particleBudget", particleBudget)));
            hue = (float) Math.max(0, Math.min(1, n(p, "hue", hue)));
            scale = (float) Math.max(.5, Math.min(2, n(p, "scale", scale)));
            wingSize = (float) Math.max(.5, Math.min(2, n(p, "wingSize", wingSize)));
            speed = (float) Math.max(.25, Math.min(3, n(p, "speed", speed)));
            opacity = (float) Math.max(.2, Math.min(1, n(p, "opacity", opacity)));
            maxDistance = Math.max(8, Math.min(96, n(p, "maxDistance", maxDistance)));
        } catch (Exception ignored) {
        }
    }

    public static void save() {
        try {
            Properties p = new Properties();
            put(p, "master", master); put(p, "halo", halo); put(p, "wings", wings); put(p, "cape", cape);
            put(p, "others", others); put(p, "particles", particles); put(p, "aura", aura); put(p, "trail", trail);
            put(p, "hitSparks", hitSparks); put(p, "autoPerf", autoPerf); put(p, "fogTint", fogTint); put(p, "hud", hud);
            put(p, "theme", theme); put(p, "particleType", particleType); put(p, "particleBudget", particleBudget);
            put(p, "hue", hue); put(p, "scale", scale); put(p, "wingSize", wingSize); put(p, "speed", speed);
            put(p, "opacity", opacity); put(p, "maxDistance", maxDistance);
            try (Writer w = Files.newBufferedWriter(file())) { p.store(w, "FLR Visuals"); }
        } catch (Exception ignored) {
        }
    }

    private static void put(Properties p, String k, Object v) { p.setProperty(k, String.valueOf(v)); }
    private static boolean b(Properties p, String k, boolean d) { String v = p.getProperty(k); return v == null ? d : Boolean.parseBoolean(v); }
    private static double n(Properties p, String k, double d) {
        try { String v = p.getProperty(k); return v == null ? d : Double.parseDouble(v); } catch (NumberFormatException e) { return d; }
    }
}
