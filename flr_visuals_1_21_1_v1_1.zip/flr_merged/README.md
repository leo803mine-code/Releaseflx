# FLR Visuals 1.1 — NeoForge 1.21.1 (client only)

## What's new in 1.1
- **Fixed:** cosmetics layer was never registered (nothing rendered); cape had zero height; wing/halo quads were bow-tied.
- New tabbed panel (O): toggles, sliders, theme swatches, presets, live player preview, scrolling, saved config.
- Themes: 5 presets + Custom hue + Rainbow. Opacity, animation speed, effect scale, wing size.
- Particle styles (Dust in theme colour, End Rod, Soul Flame, Flame, Electric, Cherry, Glow), budget slider.
- Auto performance (cuts particles on low FPS), fog tint, HUD badge, show on other players.
- Presets: Minimal / Balanced / Max. Settings saved to `config/flrvisuals.properties`.

## Controls
- O — menu (O again closes) · P — master toggle (action-bar message)
